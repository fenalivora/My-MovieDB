package com.creole.moviedb.rest;

import android.view.View;

/**
 * Created by admin1234 on 6/13/17.
 */

public interface CustomClickVideoListener {

    public void onItemClick(View view, int position);
}
