package com.creole.moviedb.rest;

import android.view.View;

import com.creole.moviedb.model.Movie;

/**
 * Created by admin1234 on 6/5/17.
 */

public interface CustomClickItemListener {

    public void onItemClick(Movie movie);
}
